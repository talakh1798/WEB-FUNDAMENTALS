// Factorial
let a=1;
for(let i=1; i<=12;i++){
    a*=i;

}
console.log(a);
