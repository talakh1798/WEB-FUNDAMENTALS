// Decreasing Multiples of 3
for (i=100; i>=0 ; i--){
    while(i%3==0){
        console.log(i);
        i--;
    }
}