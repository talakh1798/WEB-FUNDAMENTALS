
// Print the sequence
for(i=4; i>=-3.5; i-=1.5){
    console.log(i);
 }