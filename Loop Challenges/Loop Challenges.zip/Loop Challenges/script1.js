// Print odds 1-20
for (i=1; i<=20;i++){
    while(i%2 !=0){
        console.log(i);
        i++;
        
    }   
}





