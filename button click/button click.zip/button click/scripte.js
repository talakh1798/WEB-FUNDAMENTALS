function loginOut(element){
    element.innerText="login Out"
}
function Hide(element){
   element.remove()
}